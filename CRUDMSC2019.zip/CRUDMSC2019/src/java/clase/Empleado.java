package clase;

public class Empleado
{
    int clave;
    String nombre;
    String sueldo;

    public Empleado()
    {
    }

    public int getClave()
    {
        return clave;
    }

    public void setClave(int clave)
    {
        this.clave = clave;
    }

    public String getNombre()
    {
        return nombre;
    }

    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    public String getSueldo()
    {
        return sueldo;
    }

    public void setSueldo(String sueldo)
    {
        this.sueldo = sueldo;
    } 
}
