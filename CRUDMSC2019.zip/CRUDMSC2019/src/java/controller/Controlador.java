package controller;

import conexion.Conexion;
import clase.Empleado;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Controlador
{  
    Conexion con = new Conexion();
    JdbcTemplate jdbctemplate = new JdbcTemplate(con.Conectar());
    ModelAndView nav = new ModelAndView();
    
    //metodo para obtener un listado de registros de la tabla empleados
    @RequestMapping("index.htm")
    public ModelAndView Listar()
    {
        String cadsql="select * from empleados";
        List datos = this.jdbctemplate.queryForList(cadsql);
        nav.addObject("lista", datos);
        nav.setViewName("index");
        
        return nav;
    }
    
    @RequestMapping("eliminar.htm")
    public ModelAndView Borrar(HttpServletRequest request)
    {
        int clave =Integer.parseInt(request.getParameter("clave"));
        String cadsql="delete from empleados where clave="+ clave;
        this.jdbctemplate.update(cadsql);
        return new ModelAndView("redirect:/index.htm");   
    }
    
    @RequestMapping(value = "agregar.htm", method = RequestMethod.GET)
    public ModelAndView Agregar()
    {
        nav.addObject(new Empleado());
        nav.setViewName("agregar");
        return nav;    
    }
    
    @RequestMapping(value = "agregar.htm", method = RequestMethod.POST)
    public ModelAndView Agregar(Empleado p)
    {
        String cadsql="insert into empleados(clave, nombre, sueldo) values(?,?,?)";
        this.jdbctemplate.update(cadsql,p.getClave(),p.getNombre(),p.getSueldo());
        return new ModelAndView("redirect:/index.htm");
        
    }
    
    @RequestMapping(value="editar.htm", method = RequestMethod.GET)
    public ModelAndView Editar(HttpServletRequest request){
        int clave = Integer.parseInt(request.getParameter("clave"));
        String cadsql="select * from empleados where clave="+ clave;
        List datos = this.jdbctemplate.queryForList(cadsql);
        nav.addObject("lista",datos);
        nav.setViewName("editar");
        return nav;
    }
    
    @RequestMapping(value="editar.htm", method = RequestMethod.POST)
    public ModelAndView Editar(Empleado p)
    {
        int clave= p.getClave();
        String cadsql="update empleados set nombre= ?, sueldo= ? where clave=" + clave;
        this.jdbctemplate.update(cadsql,p.getNombre(), p.getSueldo());
        return new ModelAndView("redirect:/index.htm");
    }
}
